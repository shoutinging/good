#!/bin/bash
/opt/lme/Chapter\ 3\ Files/deploy.sh update
