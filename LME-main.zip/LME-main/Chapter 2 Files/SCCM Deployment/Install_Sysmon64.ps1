﻿C:\WINDOWS\Sysmon64.exe -i c:\WINDOWS\sysmonconf.xml -accepteula
